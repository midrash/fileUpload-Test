package com.ssafy.self.model.service;

import java.util.List;

import com.ssafy.self.model.dto.Problem;

public interface ProblemService {

	List<Problem> slelctProblem();

}