package com.ssafy.self.model.mapper;

import java.util.List;

import com.ssafy.self.model.dto.Problem;

public interface ProblemMapper {
	List<Problem> selectProblem();
}
