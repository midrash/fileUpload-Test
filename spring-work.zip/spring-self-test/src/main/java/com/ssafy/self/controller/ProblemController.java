package com.ssafy.self.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ProblemController {

	
}
