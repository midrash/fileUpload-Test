package com.ssafy.fileupload05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fileupload05BoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
