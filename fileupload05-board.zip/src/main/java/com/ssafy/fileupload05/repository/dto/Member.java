package com.ssafy.fileupload05.repository.dto;

public class Member {

}
