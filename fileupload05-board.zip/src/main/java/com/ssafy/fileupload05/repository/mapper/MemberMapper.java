package com.ssafy.fileupload05.repository.mapper;

public interface MemberMapper {

}
